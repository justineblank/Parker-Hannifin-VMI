﻿/// <autosync enabled="true" />
/// <reference path="js/script.js" />
/// <reference path="js/skin.config.js" />
/// <reference path="lib/validate/jquery.validate.min.js" />
